#ifndef STYLE
#define STYLE

class Style {
public:

private:

};

#endif // STYLE

